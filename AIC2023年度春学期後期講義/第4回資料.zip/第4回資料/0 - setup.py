# Databricks notebook source
# 各個人のスキーマを作る
schema_name = "toyohara"

# COMMAND ----------

spark.conf.set('schema.warehouse', schema_name + "_warehouse")
spark.conf.set('schema.mart', schema_name + "_mart")