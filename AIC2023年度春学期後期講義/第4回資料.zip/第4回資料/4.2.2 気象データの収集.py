# Databricks notebook source
# MAGIC %run "./0 - setup"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4.2.2 気象情報

# COMMAND ----------

# MAGIC %md
# MAGIC センサの情報だけではなく、気象情報を合わせて見たいので、取得する

# COMMAND ----------

# MAGIC %md
# MAGIC 今回は`Weather Forecast API`というサイトから気象情報を収集する<br>
# MAGIC 緯度・経度を指定すると、その地点の気象情報を取得できる<br>
# MAGIC （サイト） https://open-meteo.com/en/docs<br>
# MAGIC （使い方） https://paiza.hatenablog.com/entry/2021/11/04/130000

# COMMAND ----------

# MAGIC %md
# MAGIC （例）矢上キャンパスの現在の気象情報（一時間おきに更新）<br>
# MAGIC https://api.open-meteo.com/v1/forecast?latitude=35.555665596473&longitude=139.65387778239&current_weather=true&timezone=Asia%2FTokyo

# COMMAND ----------

# MAGIC %md
# MAGIC コードで取得できるようにする

# COMMAND ----------

import requests

r = requests.get('https://api.open-meteo.com/v1/forecast?latitude=35.555665596473&longitude=139.65387778239&current_weather=true&timezone=Asia%2FTokyo').json()
print(r)

# COMMAND ----------

# MAGIC %md
# MAGIC Pythonによるデータの切り出しの確認

# COMMAND ----------

print(r['current_weather']['temperature'])
print(r['current_weather']['windspeed'])
print(r['current_weather']['weathercode'])
print(r['current_weather']['is_day'])
print(r['current_weather']['time'])

# COMMAND ----------

# MAGIC %md
# MAGIC テーブルの作成

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS main.${schema.warehouse}.weather
# MAGIC (`datetime` timestamp,
# MAGIC `temperature` float,
# MAGIC `windspeed` float,
# MAGIC `weathercode` int,
# MAGIC `is_day` int)

# COMMAND ----------

# MAGIC %md
# MAGIC クエリの作成

# COMMAND ----------

query = f"INSERT INTO main." + spark.conf.get("schema.warehouse") + ".weather VALUES"
query = query + f" ('{r['current_weather']['time']}',"
query = query + f" {r['current_weather']['temperature']},"
query = query + f" {r['current_weather']['windspeed']},"
query = query + f" {r['current_weather']['weathercode']},"
query = query + f" {r['current_weather']['is_day']});"

print(query)

# COMMAND ----------

# MAGIC %md
# MAGIC クエリの実行

# COMMAND ----------

spark.sql(query)

# COMMAND ----------

# MAGIC %md
# MAGIC 確認

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.${schema.warehouse}.weather

# COMMAND ----------

