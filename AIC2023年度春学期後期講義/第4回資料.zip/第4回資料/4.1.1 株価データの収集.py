# Databricks notebook source
# MAGIC %run "./0 - setup"

# COMMAND ----------

# MAGIC %md
# MAGIC # 4.1 株価データ

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4.1.1 データ収集

# COMMAND ----------

# MAGIC %md
# MAGIC 株価データについて扱います

# COMMAND ----------

# MAGIC %md
# MAGIC #### Webスクレイピング
# MAGIC Webページの情報(HTML)を収集し、抽出・加工などの処理を行うこと

# COMMAND ----------

# MAGIC %md
# MAGIC #### 今回使うライブラリ
# MAGIC   - Requests
# MAGIC     - URLからWEBページの情報を取得
# MAGIC   - Beautiful Soup
# MAGIC     - WEBページの情報から必要なデータを抽出
# MAGIC   
# MAGIC (参考) https://ai-inter1.com/beautifulsoup_1/

# COMMAND ----------

# MAGIC %md
# MAGIC 必要なモジュールのインポート

# COMMAND ----------

!pip install beautifulsoup4

from datetime import datetime
import re

import requests
from bs4 import BeautifulSoup

# COMMAND ----------

# MAGIC %md
# MAGIC 試しにyahooファイナンスの日経平均株価のページを取得してみる<br>
# MAGIC https://finance.yahoo.co.jp/quote/998407.
# MAGIC

# COMMAND ----------

req = requests.get('https://finance.yahoo.co.jp/quote/998407.O')
soup = BeautifulSoup(req.text, 'html.parser')
soup

# COMMAND ----------

# MAGIC %md
# MAGIC 現在の株価のデータを抽出する

# COMMAND ----------

elements = [span.get_text() for span in soup.find_all('span')]
finder = re.compile("^\d+")
for element in elements:
    res = finder.match(element)
    if res is not None:
        # first value is the latest price
        price = float(element.replace(',', ''))
        break
price

# COMMAND ----------

# MAGIC %md
# MAGIC 上記と同じ手法を用いて、5つの株価データを取ってみる

# COMMAND ----------

url_dict ={
    "Nikkei225": 'https://finance.yahoo.co.jp/quote/998407.O',
    "TOPIX": 'https://finance.yahoo.co.jp/quote/998405.T',
    "NYDow": 'https://finance.yahoo.co.jp/quote/%5EDJI',
    "NASDAQ": 'https://finance.yahoo.co.jp/quote/%5EIXIC',
    "S&P500": "https://finance.yahoo.co.jp/quote/%5EGSPC"
}

now_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
price_dict = {}

finder = re.compile("^\d+")
for name, url in url_dict.items():
    req = requests.get(url)
    soup = BeautifulSoup(req.text, 'html.parser')

    elements = [span.get_text() for span in soup.find_all('span')]
    for element in elements:
        res = finder.match(element)
        if res is not None:
            # first value is the latest price
            price = float(element.replace(',', ''))
            price_dict[name] = price
            break

print(price_dict)
print(now_time)

# COMMAND ----------

# MAGIC %md
# MAGIC データを格納するテーブルを作成する

# COMMAND ----------

# MAGIC %sql
# MAGIC -- もしテーブルが存在していなければテーブルを作成する
# MAGIC CREATE TABLE IF NOT EXISTS main.${schema.warehouse}.stock
# MAGIC (`datetime` timestamp,
# MAGIC `Nikkei225` float,
# MAGIC `TOPIX` float,
# MAGIC `NYDow` float,
# MAGIC `NASDAQ` float,
# MAGIC `S&P500` float)

# COMMAND ----------

# MAGIC %md
# MAGIC 作成したテーブルに、スクレイピングで取ってきたデータをINSERT（挿入）する<br>
# MAGIC 今回はpythonでSQLクエリを作成して、pythonからクエリを実行してみる

# COMMAND ----------

query = f"INSERT INTO main." + spark.conf.get("schema.warehouse") + ".stock VALUES"
query = query + f" ('{now_time}',"
for k, v in price_dict.items():
    query = query + f"{v},"
query = query[:-1] + ");"

print(query)

# COMMAND ----------

# MAGIC %md
# MAGIC クエリの実行

# COMMAND ----------

spark.sql(query)

# COMMAND ----------

# MAGIC %md
# MAGIC 正しくデータが挿入されているか、確認してみる

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.${schema.warehouse}.stock

# COMMAND ----------

# MAGIC %md
# MAGIC 今回はこのファイルをスケジュール実行することで、擬似ストリームデータとする（実行間隔は15分）<br>
# MAGIC 実際にはこのようにスクレイピングでデータを取ってくるケースや、ログデータなどがシステムから吐き出されるようなケースを想定