# Databricks notebook source
# MAGIC %run "./0 - setup"

# COMMAND ----------

# MAGIC %md
# MAGIC # 4.2 IoTデータ

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4.2.1 センサデータ

# COMMAND ----------

# MAGIC %md
# MAGIC 使うセンサは「アルプスアルパイン IoT Smart Network Module」（現在は製造停止されています）<br>
# MAGIC Buletooth経由でデータを取得可能<br>
# MAGIC <img src="https://www.west.sd.keio.ac.jp/~toyohara/alps.jpg" width=40%><br>
# MAGIC https://e-junction.co.jp/products/detail.php?product_id=482247<br>

# COMMAND ----------

# MAGIC %md
# MAGIC 矢上キャンパスのSD西研の豊原の机の上に置いてあります<br>
# MAGIC センサの値はBuletooth経由で取得するので、近くにラズパイ（Raspberry Pi）というミニPCを置いておき、センサからデータを受け取ります<br>
# MAGIC ラズパイはインターネット（Wi-Fi）に接続してあるので、ラズパイからデータを受け取ることができます<br>
# MAGIC 今回はMQTTというIoTの世界でよく使われるデータの交換方式を使って、ラズパイと通信を行っています
# MAGIC <br><br>
# MAGIC <img src="https://www.west.sd.keio.ac.jp/~toyohara/IoT.png"><br>

# COMMAND ----------

# MAGIC %md
# MAGIC MQTTとは？<br>
# MAGIC https://tech-blog.rakus.co.jp/entry/20180912/mqtt/iot/beginner

# COMMAND ----------

# MAGIC %md
# MAGIC MQTT経由でラズパイからセンサのデータを受け取る<br>
# MAGIC (参考) https://qiita.com/hsgucci/items/6461d8555ea1245ef6c2

# COMMAND ----------

# MAGIC %md
# MAGIC ライブラリのインストール

# COMMAND ----------

!pip install paho-mqtt

import paho.mqtt.client as mqtt
import time
import json

# COMMAND ----------

# MAGIC %md
# MAGIC とりあえず実行してみる<br>
# MAGIC センサから1分置きにデータを取得しているため、待っているとデータが受け取れる

# COMMAND ----------

# 定数定義
host = 'broker.hivemq.com'
port = 1883
topic = 'keio-aic-data-engineering/sensor'

# 接続
def on_connect(client, userdata, flags, rc):
    # 戻り値チェック
    print("Connected with result code " + str(rc))
    # サブスクライブ
    client.subscribe(topic)

# 受信
def on_message(client, userdata, msg):
    global on_message_Flag
    global mqtt_msg
    mqtt_msg = msg
    print('topic:[' + msg.topic + '] payload:[' + str(msg.payload) + ']')
    on_message_Flag=True # flagを有効化

# プロトコルを v3.1.1 を指定
client = mqtt.Client(protocol=mqtt.MQTTv311)
# ハンドラー設定
client.on_connect = on_connect
client.on_message = on_message
# 接続
client.connect(host, port=port, keepalive=60)
# 受信ループ
client.loop_start()
on_message_Flag=False
while True:
    if on_message_Flag:
        break
client.disconnect()
client.loop_stop()

# COMMAND ----------

# MAGIC %md
# MAGIC データをデコードして、データを見てみる

# COMMAND ----------

sensor_data = json.loads(mqtt_msg.payload.decode("utf-8"))
sensor_data

# COMMAND ----------

# MAGIC %md
# MAGIC 今回は気圧・湿度・温度・紫外線量・可視光量を取得しています

# COMMAND ----------

# MAGIC %md
# MAGIC データを格納するためのテーブルの作成

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS main.${schema.warehouse}.sensor
# MAGIC (`datetime` timestamp,
# MAGIC `Pressure` float,
# MAGIC `Humidity` float,
# MAGIC `Temperature` float,
# MAGIC `UV` float,
# MAGIC `AmbientLight` float)

# COMMAND ----------

# MAGIC %md
# MAGIC クエリの作成

# COMMAND ----------

query = f"INSERT INTO main." + spark.conf.get("schema.warehouse") + ".sensor VALUES"
query = query + f" ('{sensor_data['datetime']}',"
query = query + f" {sensor_data['Pressure']},"
query = query + f" {sensor_data['Humidity']},"
query = query + f" {sensor_data['Temperature']},"
query = query + f" {sensor_data['UV']},"
query = query + f" {sensor_data['AmbientLight']});"

print(query)

# COMMAND ----------

# MAGIC %md
# MAGIC クエリの実行

# COMMAND ----------

spark.sql(query)

# COMMAND ----------

# MAGIC %md
# MAGIC INSERTできたか確認

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.${schema.warehouse}.sensor

# COMMAND ----------

