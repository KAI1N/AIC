# Databricks notebook source
# MAGIC %md
# MAGIC # データエンジニアリング入門
# MAGIC ## 第4回 データ活用実践応用編 ストリームデータを用いたデータ活用

# COMMAND ----------

# MAGIC %md
# MAGIC ### 講師
# MAGIC - M2 豊原
# MAGIC ### TA
# MAGIC - M2 西川
# MAGIC - B3 勝又
# MAGIC - B2 好田

# COMMAND ----------

# MAGIC %md
# MAGIC 今日は第2回と第3回の内容の復習が中心となります<br>
# MAGIC ストリームデータを題材とし、データの取得・加工・可視化の一連の流れを体験します．

# COMMAND ----------

# MAGIC %md
# MAGIC ### データの取り込み（再掲）
# MAGIC - <b>バッチ処理</b>
# MAGIC     - 一定量のデータのまとまりを取り込む（例：1日、1週間、1か月）
# MAGIC - <b>ストリーム処理</b>
# MAGIC     - データが発生したらすぐに取り込み、リアルタイムな処理を行う
# MAGIC     - このようなデータをストリームデータと呼ぶ（例：センサデータ、WEBログデータ）

# COMMAND ----------

# MAGIC %md
# MAGIC ## （おまけ）自習向けコンテンツ

# COMMAND ----------

# MAGIC %md
# MAGIC Databricksのような環境を自前で用意することは難しいので、簡単にSQLの演習が行えるようなツールを紹介します！

# COMMAND ----------

# MAGIC %md
# MAGIC ### SQLを実行しながら学べるサイト
# MAGIC - SQLab
# MAGIC     - https://sqlab.net/
# MAGIC - SQL攻略 Web上でSQLを実行しながらマスターするサイト
# MAGIC     - http://sql.main.jp/
# MAGIC - SQLZOO（英語だが一部日本語対応）
# MAGIC     - https://sqlzoo.net/wiki/SQL_Tutorial
# MAGIC - SQLBolt（英語）
# MAGIC     - https://sqlbolt.com/

# COMMAND ----------

# MAGIC %md
# MAGIC ### 演習したい人向け
# MAGIC - データサイエンス100本ノック（Google Colab）
# MAGIC   - https://note.com/nmt_rootassist/n/nf70b6e73f673
# MAGIC - 自分で用意したCSVデータに対してSQLを実行（Google Colab）
# MAGIC   - https://qiita.com/_jinta/items/479355d4709cd30d56c8
# MAGIC - pandasql（pandasのDataFrameをSQLで操作できる）
# MAGIC   - https://qiita.com/ground0state/items/ad996731aa905985dedd