# Databricks notebook source
# MAGIC %run "./0 - setup"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4.1.2 ETL・可視化編

# COMMAND ----------

# MAGIC %md
# MAGIC ここからは4.1.1のコードを1週間程度実行して作成したテーブルを使用します<br>
# MAGIC （現在も実行中で動的にデータは増えています）

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.stream.stock
# MAGIC order by datetime desc -- 日付を降順に並べる

# COMMAND ----------

# MAGIC %md
# MAGIC ここで日付を見ると分かるように、日本標準時（JST）ではなく、協定世界時（UTC）となっている<br>
# MAGIC （日本から-9時間）

# COMMAND ----------

# MAGIC %md
# MAGIC そのため、協定世界時（UTC）から日本標準時（JST）への変換をやってみよう！<br>
# MAGIC 今回は`from_utc_timestamp()`という関数を使って変換してみる

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC   datetime,
# MAGIC   from_utc_timestamp(datetime, "JST")
# MAGIC from main.stream.stock
# MAGIC order by datetime desc

# COMMAND ----------

# MAGIC %md
# MAGIC 日付を変換したものを新たなテーブルとしてデータマートに作成しよう！

# COMMAND ----------

# MAGIC %md
# MAGIC ## TABLE / VIEW（再掲）
# MAGIC SQLで抽出したデータを新たなテーブルとして作成することができる．<br>
# MAGIC TABLEを作成する文法はCTAS（```CREATE TABLE AS SELECT```）と呼ばれることもある．
# MAGIC - <b>TABLE</b>
# MAGIC   - 実体のあるテーブル
# MAGIC - <b>VIEW</b>
# MAGIC   - 実体はない仮想的なテーブル
# MAGIC   - だたテーブルと同じように呼び出すことができる(FROMやJOIN)
# MAGIC   - 実体がないため、VIEWが呼び出されるたびに、毎回仮想的なテーブルが作成される<br>
# MAGIC
# MAGIC <b>主な違い</b>
# MAGIC - TABLEは一度作成されると、元のテーブルが変更されても、結果は変わらない（更新をかけなければ）
# MAGIC - VIEWは呼び出されるたびに仮想的なテーブルが作成されるので、元のテーブルが変更されると、出力も変わる
# MAGIC - VIEWの方がソーステーブルのリアルタイムな更新を反映できるが、毎回仮想テーブルが作成されるので、計算コストが高い
# MAGIC - クラウド環境を利用している場合などは、計算コストが高いと使用料が高くなるのでトレードオフ
# MAGIC - リアルタイム性が求められる場合にはVIEW、それ以外はTABLEなどで使い分ける

# COMMAND ----------

# MAGIC %md
# MAGIC 今回はストリームデータのため、VIEWとして定義する！<br>
# MAGIC `create table`ではなく`create view`

# COMMAND ----------

# MAGIC %sql
# MAGIC create view if not exists main.${schema.mart}.stock_jst
# MAGIC as
# MAGIC select
# MAGIC   from_utc_timestamp(datetime, "JST") as datetime,
# MAGIC   `Nikkei225`,
# MAGIC   `TOPIX`,
# MAGIC   `NYDow`,
# MAGIC   `NASDAQ`,
# MAGIC   `S&P500`
# MAGIC from main.stream.stock

# COMMAND ----------

# MAGIC %md
# MAGIC 作成したVIEWを参照してみる

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.${schema.mart}.stock_jst

# COMMAND ----------

# MAGIC %md
# MAGIC 可視化してみる

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.${schema.mart}.stock_jst