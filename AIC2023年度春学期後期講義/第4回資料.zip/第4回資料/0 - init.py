# Databricks notebook source
# MAGIC %md
# MAGIC 環境が変わってしまったので、もう一度個人のスキーマを作成する

# COMMAND ----------

# MAGIC %run "./0 - setup"

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS main.${schema.warehouse}

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS main.${schema.mart}

# COMMAND ----------

