# Databricks notebook source
# MAGIC %run "./0 - setup"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4.2.3 ETL・可視化編

# COMMAND ----------

# MAGIC %md
# MAGIC センサデータ

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.stream.sensor
# MAGIC order by datetime desc

# COMMAND ----------

# MAGIC %md
# MAGIC 気象データ

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.stream.weather
# MAGIC order by datetime desc

# COMMAND ----------

# MAGIC %md
# MAGIC センサデータと気象データを合わせて可視化してみよう！！

# COMMAND ----------

# MAGIC %md
# MAGIC ## JOIN（再掲）
# MAGIC テーブル同士を結合することです。
# MAGIC データベースからレコードを取得する際、テーブル1とテーブル2のレコードを同時に取得したいなぁ...と思う時や、1つのテーブルだけでは情報が足りないから他のテーブルからも情報を引っ張ってこよう！と思うことがあります。そんな時に使うのがJOINです。
# MAGIC ### JOINの種類
# MAGIC テーブルの結合は大きく分けると内部結合と外部結合に分かれています。<br>どのようにテーブルを結合するかによって、SQLでの記載方法が異なります。<br>また、下記の表のように省略形で記載することもできます。
# MAGIC | 結合方法 | SQLでの記載方法 | 省略形 |
# MAGIC | --- | --- | --- |
# MAGIC | 内部結合 | INNER JOIN | JOIN |
# MAGIC | 外部結合| LEFT OUTER JOIN | LEFT JOIN |
# MAGIC | 外部結合 | RIGHT OUTER JOIN | RIGHT JOIN |
# MAGIC ### OUTER JOIN
# MAGIC 外部結合では、内部結合のように条件に一致させた状態で結合してくれるのに加え、どちらかのテーブルに存在しないもの、NULLのものに関しても強制的に取得してくれます。
# MAGIC - <b>LEFT JOIN</b>  
# MAGIC 左外部結合のことで、左のテーブルは全て表示します。
# MAGIC - RIGHT JOIN  
# MAGIC 右外部結合のことで、右のテーブルは全て表示します。
# MAGIC ### サンプル
# MAGIC ```
# MAGIC SELECT
# MAGIC   (カラムの列挙)
# MAGIC FROM 
# MAGIC   (左テーブル)
# MAGIC LEFT JOIN 
# MAGIC   （右テーブル） 
# MAGIC   ON (左テーブルのカラム) = （右テーブルのカラム）
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC 2つのテーブルを日時情報で紐づけたい<br>
# MAGIC しかし、日時の周期がずれているので紐付けが難しい（センサデータは15分ごと、気象データは1時間ごと）<br>
# MAGIC そのため、`DATE_TRUNC()`関数を使い、日付と時間までの情報を抜き出して紐づける

# COMMAND ----------

# MAGIC %md
# MAGIC 試しに、センサデータの日時情報を操作してみる！

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC   datetime,
# MAGIC   DATE_TRUNC('hour', s.datetime)
# MAGIC from main.stream.sensor as s

# COMMAND ----------

# MAGIC %md
# MAGIC 気象情報はこちら<br>
# MAGIC これならJOINできそう！

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.stream.weather

# COMMAND ----------

# MAGIC %md
# MAGIC 実際にJOINを行う！

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.stream.sensor as s
# MAGIC left join main.stream.weather as w
# MAGIC   on DATE_TRUNC('hour', s.datetime) = w.datetime

# COMMAND ----------

# MAGIC %md
# MAGIC このままだとカラム名が分かりずらいので、カラム名を編集する<br>
# MAGIC - センサデータには`s_`
# MAGIC - 気象データには`m_`

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC   s.datetime,
# MAGIC   s.Pressure as s_pressure,
# MAGIC   s.Humidity as s_humidity,
# MAGIC   s.Temperature as s_temperature,
# MAGIC   s.UV as s_uv,
# MAGIC   s.AmbientLight as s_ambienlight,
# MAGIC   w.temperature as w_temperature,
# MAGIC   w.windspeed as w_windspeed,
# MAGIC   w.weathercode as w_weathercode,
# MAGIC   w.is_day as w_isday
# MAGIC from main.stream.sensor as s
# MAGIC left join main.stream.weather as w
# MAGIC   on DATE_TRUNC('hour', s.datetime) = w.datetime
# MAGIC order by datetime desc

# COMMAND ----------

# MAGIC %md
# MAGIC これをVIEWとして定義する

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VIEW if not exists main.${schema.mart}.iot
# MAGIC AS
# MAGIC select
# MAGIC   s.datetime,
# MAGIC   s.Pressure as s_pressure,
# MAGIC   s.Humidity as s_humidity,
# MAGIC   s.Temperature as s_temperature,
# MAGIC   s.UV as s_uv,
# MAGIC   s.AmbientLight as s_ambienlight,
# MAGIC   w.temperature as w_temperature,
# MAGIC   w.windspeed as w_windspeed,
# MAGIC   w.weathercode as w_weathercode,
# MAGIC   w.is_day as w_isday
# MAGIC from main.stream.sensor as s
# MAGIC left join main.stream.weather as w
# MAGIC   on DATE_TRUNC('hour', s.datetime) = w.datetime
# MAGIC order by datetime desc

# COMMAND ----------

# MAGIC %md
# MAGIC 確認！

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.${schema.mart}.iot

# COMMAND ----------

# MAGIC %md
# MAGIC 可視化！

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.${schema.mart}.iot

# COMMAND ----------

