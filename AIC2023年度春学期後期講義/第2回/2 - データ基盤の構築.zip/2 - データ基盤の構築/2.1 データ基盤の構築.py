# Databricks notebook source
# MAGIC %md
# MAGIC # データエンジニアリング入門
# MAGIC ## 第2回 データ活用実践初級編 データ基盤の構築

# COMMAND ----------

# MAGIC %md
# MAGIC ### 講師
# MAGIC - M2 豊原
# MAGIC ### TA
# MAGIC - M2 西川
# MAGIC - B3 勝又
# MAGIC - B2 好田

# COMMAND ----------

# MAGIC %md
# MAGIC # 1．データ基盤

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.1 三層構造
# MAGIC ![データ基盤](https://www.nicpartners.co.jp/wp-content/uploads/2020/08/%E5%9B%B31-1.png) 
# MAGIC <br>【出典】 https://www.nicpartners.co.jp/report/92269/
# MAGIC <br><br>
# MAGIC - <b>データレイク</b>
# MAGIC   - 生データをそのまま保存
# MAGIC - <b>データウェアハウス(以下DWH)</b>
# MAGIC   - 生データを加工したデータを格納
# MAGIC   - テーブル形式の構造化データ
# MAGIC - <b>データマート</b>
# MAGIC   - 用途(ダッシュボードなど)別に格納

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.2 データソースについて

# COMMAND ----------

# MAGIC %md
# MAGIC ### データフォーマット
# MAGIC - <b>構造化データ</b>
# MAGIC     - テーブル形式のデータ
# MAGIC     - RDB(Relational Database:関係データベース)など
# MAGIC     <img src="https://www.west.sd.keio.ac.jp/~toyohara/rdb.png" width="80%">
# MAGIC     <br><br>
# MAGIC - <b>半構造化データ</b>
# MAGIC     - CSV、JSON、YAML、XML形式のデータ
# MAGIC     - NoSQLやログ・センサデータなど<br>
# MAGIC     <img src="https://www.west.sd.keio.ac.jp/~toyohara/json.png" width="40%">
# MAGIC     <br><br>
# MAGIC - <b>非構造化データ</b>
# MAGIC     - 画像・映像データ

# COMMAND ----------

# MAGIC %md
# MAGIC ### データの取り込み
# MAGIC - <b>バッチ処理</b>
# MAGIC     - 一定量のデータのまとまりを取り込む（例：1日、1週間、1か月）
# MAGIC - <b>ストリーム処理</b>
# MAGIC     - データが発生したらすぐに取り込み、リアルタイムな処理を行う
# MAGIC     - このようなデータをストリームデータと呼ぶ（例：センサデータ、WEBログデータ）

# COMMAND ----------

# MAGIC %md
# MAGIC ### データベース(DB)
# MAGIC DBの種類は大きく分けると2つ
# MAGIC - <b>RDB</b>
# MAGIC     - 一般的なDB
# MAGIC     - 列と行を持つテーブルの集合（構造化データ）
# MAGIC     - SQLによる操作
# MAGIC     - データの一貫性を担保
# MAGIC     - EX. MySQL、PostgreSQL、Oracle Database
# MAGIC - <b>NoSQL(Not only SQL)</b>
# MAGIC     - シンプルな構造で、高速な処理を実現
# MAGIC     - 構造化データだけではなく非構造化データと半構造化データを扱える
# MAGIC     - キーバリュー型、ドキュメント型など様々な種類がある
# MAGIC     - EX. Redis、DynamoDB、MongoDB
# MAGIC
# MAGIC ※ここで話したDBは主にアプリケーションDBのことを指します

# COMMAND ----------

# MAGIC %md
# MAGIC ### RDBの正規化
# MAGIC RDBではデータの追加・更新・削除などに伴うデータの不整合や喪失が起きるのを防ぐために、正規化されている．<br>
# MAGIC 第1正規化、第2正規化、第3正規化の順に正規化を行っていく．<br>
# MAGIC <b>RDBのテーブルは分割されているため、分析の際にはテーブルを結合する必要がある</b>、ということを知っておいてほしい．
# MAGIC <br>
# MAGIC <img src="https://breezegroup.co.jp/wp-content/uploads/2020/04/%E7%AC%AC2%E6%AD%A3%E8%A6%8F%E5%BD%A2.png" width="70%">
# MAGIC <br>【出典】 https://breezegroup.co.jp/202005/database-normalization/

# COMMAND ----------

# MAGIC %md
# MAGIC ### データの流れ
# MAGIC ここに挙げた全てのデータはデータレイクに保存される．その後、構造化・半構造化データは加工されDWHに格納される．非構造化データはML活用など必要に応じてデータレイクから取り出される．

# COMMAND ----------

# MAGIC %md
# MAGIC # 2．ETL (Extract・Transform・Load)
# MAGIC ETLとはデータの変換（加工・結合など）を行うこと．
# MAGIC - Extract （抽出）
# MAGIC - Transform （変換）
# MAGIC - Load （書き出し）
# MAGIC
# MAGIC 本来の語源としては抽出・変換・書き出しの一連の流れを表す言葉であったが、現在では主に変換を意味する言葉として使われることが多い．最近はETLだけではなく、ELT（LoadとTransformの順番が逆）という言葉もよく使われるが、厳密にはニュアンスは異なるものの、基本的には同じ変換を意味すると考えてよい．
# MAGIC <br><br>
# MAGIC 本講習会で扱うETLの処理は主に2種類
# MAGIC - ① データレイク→データウェアハウス
# MAGIC   - 半構造化データは構造化データへ加工してDWHへ取り込む
# MAGIC   - （構造化データは特に何もせずにDWHへ取り込む）
# MAGIC   - （非構造化データは対象外）
# MAGIC   - 言語：Python,Java,その他比較的なんでもあり
# MAGIC
# MAGIC - ② データウェアハウス→データマート
# MAGIC   - RDB（構造化データ）の非正規化
# MAGIC   - データに対してラベル付を行う
# MAGIC   - データマスキングにより顧客情報を秘匿する
# MAGIC   - その他データの加工
# MAGIC   - 言語：SQL,Python,その他SQLライクな言語

# COMMAND ----------

# MAGIC %md
# MAGIC # 3．Databricksの使い方
# MAGIC セルの実行
# MAGIC - ctrl + enter : 選択したセルを実行
# MAGIC - shift + enter : 選択したセルを実行して、次のセルに移動

# COMMAND ----------

# MAGIC %run "../0 - setup"

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS main.${schema.warehouse}

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS main.${schema.mart}

# COMMAND ----------

# MAGIC %md
# MAGIC # 4．ETL①をやってみよう
# MAGIC データレイク→データウェアハウス<br>
# MAGIC 半構造化データを構造化データへ加工してDWHへ取り込む<br>
# MAGIC <br>
# MAGIC - MongoDB公式のAirbnbサンプルデータ（json形式）
# MAGIC   - https://www.mongodb.com/docs/atlas/sample-data/sample-airbnb/<br>
# MAGIC   - https://github.com/neelabalan/mongodb-sample-dataset

# COMMAND ----------

# MAGIC %md
# MAGIC 必要なライブラリのインストール

# COMMAND ----------

pip install wget

# COMMAND ----------

# MAGIC %md
# MAGIC webから今回のファイルをダウンロードし、中身を見てみる

# COMMAND ----------

import urllib.request
import json
import pandas

url = 'http://west.sd.keio.ac.jp/~toyohara/sample_airbnb.json'

urllib.request.urlretrieve(url, './sample_airbnb.json')
df = [json.loads(line) for line in open("sample_airbnb.json", 'r', encoding='utf-8')]

print(df)

# COMMAND ----------

# MAGIC %md
# MAGIC pandas形式に変換

# COMMAND ----------

airbnb_data = pandas.json_normalize(df)
airbnb_data

# COMMAND ----------

# MAGIC %md
# MAGIC 今回は分かりやすく、最初の3カラムのみ抽出してテーブルへ書き出す

# COMMAND ----------

extract_data = airbnb_data [['_id','listing_url','name']]
extract_data

# COMMAND ----------

# MAGIC %md
# MAGIC 上のデータに関するスキーマ（テーブルの情報）を見てみる

# COMMAND ----------

spark_df = spark.createDataFrame(extract_data)
spark_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC _idのデータ型がstringとなっているため、intにする<br>
# MAGIC _idというカラム名をidに変更する

# COMMAND ----------

# 型変換
spark_df = spark_df.withColumn("_id",spark_df["_id"].cast('int'))
# カラム名変更
spark_df = spark_df.withColumnRenamed("_id", "id")

# COMMAND ----------

spark_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC テーブルへ書き出し

# COMMAND ----------

spark_df.write.saveAsTable("main." + spark.conf.get("schema.warehouse") + ".airbnb")

# COMMAND ----------

# MAGIC %md
# MAGIC 作成されたテーブルを確認する

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   main.${schema.warehouse}.airbnb

# COMMAND ----------

# MAGIC %md
# MAGIC # 5．SQL

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5.1 SQLとは？
# MAGIC Structured Query Languageの略で、RDB（構造化データ）を操作するための言語．<br>
# MAGIC SQLには様々な機能があるが、本講習会では「データを分析する」という部分に着目して紹介する．

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5.2 SELECT / FROM
# MAGIC - <b>SELECT</b>
# MAGIC   - 参照する列を指定する
# MAGIC   - 列名をカンマ区切りで列挙する
# MAGIC   - ```*```で全ての列名を選択することができる
# MAGIC - <b>FROM</b>
# MAGIC   - 参照するテーブルを指定する
# MAGIC - <b>コメントアウト</b>
# MAGIC   - 一行のコメントアウトは頭に```-- コメント```を付ける
# MAGIC   - 複数行のコメントアウトは```/* コメント */```で囲う

# COMMAND ----------

# MAGIC %md
# MAGIC ```
# MAGIC SELECT
# MAGIC   (カラム1),（カラム2）,（カラム3）
# MAGIC FROM
# MAGIC   (テーブル名)
# MAGIC ```

# COMMAND ----------

# MAGIC %sql
# MAGIC -- フルーツテーブルのname、fruits、numカラムを表示する
# MAGIC SELECT
# MAGIC   name,fruits,num
# MAGIC FROM
# MAGIC   main.fruits.fruits_table

# COMMAND ----------

# MAGIC %sql
# MAGIC -- フルーツテーブルの全てのカラムを表示する
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   main.fruits.fruits_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5.3 WHERE
# MAGIC - <b>WHERE</b>
# MAGIC   - あるカラムに対して、条件を指定することができる
# MAGIC   - 複数の条件を```AND```や```OR```で繋げることができる
# MAGIC
# MAGIC <b>WHEREで使える演算子</b>
# MAGIC |記号|意味|例|
# MAGIC |---|---|---|
# MAGIC |=、!=|等しい、等しくない|```WHERE name = "toyohara"```|
# MAGIC |<、>、<=、>=|大小比較|```WHERE num >= 3```|
# MAGIC |AND、OR|複数の条件を結合|```WHERE fruits = "apple" OR fruits = "orange"```|
# MAGIC |IS NULL、IS NOT NULL|値がNULLかどうかの判定|```WHERE num IS NOT NULL```|
# MAGIC
# MAGIC ※その他、BETWEEN、IN、LIKEなどもあります

# COMMAND ----------

# MAGIC %md
# MAGIC ```
# MAGIC SELECT
# MAGIC   (カラム名)
# MAGIC FROM 
# MAGIC   (テーブル名)
# MAGIC WHERE
# MAGIC   (条件式)
# MAGIC ```

# COMMAND ----------

# MAGIC %sql
# MAGIC -- nameがtoyoharaのレコードのみ抽出
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   main.fruits.fruits_table
# MAGIC WHERE
# MAGIC   name = "toyohara"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5.4 GROUP BY / 集計関数
# MAGIC - GROUP BY
# MAGIC   - 指定したカラムでグルーピングを行う
# MAGIC   - SELECTの中には<b>指定したカラム</b>と<b>集計関数</b>しか使えない
# MAGIC - 集計関数
# MAGIC   - 集計をするための関数
# MAGIC
# MAGIC |集計関数|動作|
# MAGIC |---|---|
# MAGIC |COUNT(X)|カラムXの件数を返す、```*```で指定するとレコード数を返す|
# MAGIC |SUM(X)|カラムXの合計値を返す|
# MAGIC |AVG(X)|カラムXの平均値を返す|
# MAGIC |MAX(X)|カラムXの最大値を返す|
# MAGIC |MIN(X)|カラムXの最小値を返す|

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 一人当たりの平均果物数
# MAGIC SELECT
# MAGIC   name,
# MAGIC   avg(num)
# MAGIC FROM 
# MAGIC   main.fruits.fruits_table
# MAGIC GROUP BY
# MAGIC   name

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 果物ごとの合計
# MAGIC SELECT
# MAGIC   fruits,
# MAGIC   sum(num)
# MAGIC FROM 
# MAGIC   main.fruits.fruits_table
# MAGIC GROUP BY
# MAGIC   fruits

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 一人当たり何行レコードがあるか
# MAGIC SELECT
# MAGIC   name,
# MAGIC   count(*)
# MAGIC FROM 
# MAGIC   main.fruits.fruits_table
# MAGIC GROUP BY
# MAGIC   name

# COMMAND ----------

# MAGIC %sql
# MAGIC -- エラーの出るコードです!!
# MAGIC -- GROUP BYで指定していないカラムをSELECT内に書いている
# MAGIC SELECT
# MAGIC   name,
# MAGIC   count(*)
# MAGIC FROM 
# MAGIC   main.fruits.fruits_table
# MAGIC GROUP BY
# MAGIC   fruits

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5.5 CASE
# MAGIC - <b>CASE</b>
# MAGIC   - SELECTの中で使う
# MAGIC   - 条件に応じた新しいカラムを宣言することができる
# MAGIC   - イメージとしてはIF文に近い

# COMMAND ----------

# MAGIC %md
# MAGIC ```
# MAGIC SELECT
# MAGIC   CASE
# MAGIC     WHEN (条件式1) THEN (出力1)
# MAGIC     WHEN (条件式2) THEN (出力2)
# MAGIC     WHEN (条件式3) THEN (出力3)
# MAGIC   END AS (カラム名)
# MAGIC FROM (テーブル名)
# MAGIC ```

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   *,
# MAGIC   CASE
# MAGIC     WHEN num < 3 THEN "0-2"
# MAGIC     WHEN 3 <= num AND num < 6 THEN "3-5"
# MAGIC     WHEN 6 <= num AND num < 9 THEN "6-9"
# MAGIC   END AS num_label
# MAGIC FROM 
# MAGIC   main.fruits.fruits_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5.6 その他
# MAGIC SQLの文法は順番が決まっています．
# MAGIC 1. <b>select</b>　⇒　列(カラム)を指定
# MAGIC 1. <b>from</b>　⇒　テーブルを指定
# MAGIC 1. join　⇒　複数テーブルの結合処理（第3回で扱います）
# MAGIC 1. <b>where</b>　⇒　絞り込み条件の指定
# MAGIC 1. <b>group by</b>　⇒　グループ条件の指定
# MAGIC 1. having　⇒　グループ化後の絞り込み条件の指定（今回は扱いません、whereと似た処理）
# MAGIC 1. order by　⇒　ソート順の指定
# MAGIC 1. limit　⇒　取得する行数の指定

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5.7 TABLE / VIEW
# MAGIC SQLで抽出したデータを新たなテーブルとして作成することができる．<br>
# MAGIC TABLEを作成する文法はCTAS（```CREATE TABLE AS SELECT```）と呼ばれることもある．
# MAGIC - <b>TABLE</b>
# MAGIC   - 実体のあるテーブル
# MAGIC - <b>VIEW</b>
# MAGIC   - 実体はない仮想的なテーブル
# MAGIC   - だたテーブルと同じように呼び出すことができる(FROMやJOIN)
# MAGIC   - 実体がないため、VIEWが呼び出されるたびに、毎回仮想的なテーブルが作成される<br>
# MAGIC
# MAGIC <b>主な違い</b>
# MAGIC - TABLEは一度作成されると、元のテーブルが変更されても、結果は変わらない（更新をかけなければ）
# MAGIC - VIEWは呼び出されるたびに仮想的なテーブルが作成されるので、元のテーブルが変更されると、出力も変わる
# MAGIC - VIEWの方がソーステーブルのリアルタイムな更新を反映できるが、毎回仮想テーブルが作成されるので、計算コストが高い
# MAGIC - クラウド環境を利用している場合などは、計算コストが高いと使用料が高くなるのでトレードオフ
# MAGIC - リアルタイム性が求められる場合にはVIEW、それ以外はTABLEなどで使い分ける

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SQLクエリの結果でTABLEを作成する
# MAGIC CREATE TABLE main.${schema.mart}.fruits_toyohara
# MAGIC AS
# MAGIC SELECT *
# MAGIC FROM main.fruits.fruits_table
# MAGIC WHERE name = "toyohara"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM main.${schema.mart}.fruits_toyohara

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SQLクエリの結果でVIEWを作成する
# MAGIC CREATE VIEW main.${schema.mart}.fruits_nishikawa_view
# MAGIC AS
# MAGIC SELECT *
# MAGIC FROM main.fruits.fruits_table
# MAGIC WHERE name = "nishikawa"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM main.${schema.mart}.fruits_nishikawa_view

# COMMAND ----------

# MAGIC %md
# MAGIC # 6．②をやってみよう
# MAGIC データウェアハウス→データマート<br>
# MAGIC データに対してラベル付を行う<br>
# MAGIC <br>
# MAGIC - Amazon Redshift公式チュートリアルのサンプルデータ
# MAGIC   - https://docs.aws.amazon.com/ja_jp/redshift/latest/dg/tutorial-loading-data.html
# MAGIC   - https://docs.aws.amazon.com/ja_jp/redshift/latest/dg/tutorial-loading-data-create-tables.html
# MAGIC - RDBのため、正規化されたテーブルが複数ある

# COMMAND ----------

# MAGIC %md
# MAGIC <img src="https://docs.aws.amazon.com/ja_jp/redshift/latest/dg/images/tutorial-optimize-tables-ssb-data-model.png">
# MAGIC <br>【出典】 https://docs.aws.amazon.com/ja_jp/redshift/latest/dg/tutorial-loading-data-create-tables.html

# COMMAND ----------

# MAGIC %md
# MAGIC 今日は真ん中のLINEORDERテーブルのみ使う<br>
# MAGIC とりあえず中身を見てみる

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.redshift.lineorder
# MAGIC limit 10 -- 10行だけ表示する

# COMMAND ----------

# MAGIC %md
# MAGIC 顧客の購入数に応じて、顧客に会員ランクを付ける
# MAGIC |ランク|購入数|
# MAGIC |---|---|
# MAGIC |ブロンズ|50未満|
# MAGIC |シルバー|50以上100未満|
# MAGIC |ゴールド|100以上150未満|
# MAGIC |プラチナ|150以上|

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC   lo_custkey,
# MAGIC   case
# MAGIC     when count(*) < 50 then "Bronze"
# MAGIC     when 50 <= count(*) and count(*) < 100 then "Silver"
# MAGIC     when 100 <= count(*) and count(*) < 150 then "Gold"
# MAGIC     when 150 <= count(*) then "Platinum"
# MAGIC   end as customer_rank
# MAGIC from main.redshift.lineorder
# MAGIC group by lo_custkey

# COMMAND ----------

# MAGIC %md
# MAGIC 上記のクエリを用いてテーブルを作成する

# COMMAND ----------

# MAGIC %sql
# MAGIC create table main.${schema.mart}.customer_rank
# MAGIC as
# MAGIC select
# MAGIC   lo_custkey,
# MAGIC   case
# MAGIC     when count(*) < 50 then "Bronze"
# MAGIC     when 50 <= count(*) and count(*) < 100 then "Silver"
# MAGIC     when 100 <= count(*) and count(*) < 150 then "Gold"
# MAGIC     when 150 <= count(*) then "Platinum"
# MAGIC   end as customer_rank
# MAGIC from main.redshift.lineorder
# MAGIC group by lo_custkey

# COMMAND ----------

# MAGIC %md
# MAGIC 作成したテーブルの中身を見てみる

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from main.${schema.mart}.customer_rank

# COMMAND ----------

# MAGIC %md
# MAGIC 各ランクごとの人数を見てみる

# COMMAND ----------

# MAGIC %sql
# MAGIC select customer_rank,count(*)
# MAGIC from main.${schema.mart}.customer_rank
# MAGIC group by customer_rank

# COMMAND ----------

# MAGIC %md
# MAGIC 他のユーザがランクを見たいときは、今回作成したcustomer_rankのテーブルを参照してもらう<br>
# MAGIC 定義を変更したいときには、このテーブルのクエリを変更するだけでよい